export { DeliveryDriversManagement as default } from "../../components/admin/screens/DeliveryDriversManagement";

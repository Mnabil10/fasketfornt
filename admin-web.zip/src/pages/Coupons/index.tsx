export { CouponsManagement as default } from '../../components/admin/screens/CouponsManagement'


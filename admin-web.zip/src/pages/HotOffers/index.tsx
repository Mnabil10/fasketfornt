export { HotOffersList as default } from '../../components/admin/screens/HotOffers'


export { DeliveryZonesManagement as default } from "../../../components/admin/screens/DeliveryZonesManagement";
